!#/bin/sh
python /home/xubuntu/distribuido/scripts/top.py